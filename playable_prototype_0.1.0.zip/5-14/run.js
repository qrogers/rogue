function ai() {

	this.seek_and_attack_player = function(enemy) {
		if(are_adjacent(enemy, player)) {
			enemy.attack_enemy(player);
			return [0, 0];
		} else {
			var x_or_y = random_range(0, 1);
			       if(enemy.x < player.x && enemy.y === player.y) {
				return [1, 0];
			} else if(enemy.x > player.x && enemy.y === player.y) {
				return [-1, 0];
			} else if(enemy.y > player.y && enemy.x === player.x) {
				return [0, -1];
			} else if(enemy.y < player.y && enemy.x === player.x) {
				return [0, 1];
			} else if(enemy.x !== player.x) {
				if(x_or_y === 0) {
					if(enemy.x < player.x) {
						return [1, 0];
					} else if(enemy.x > player.x) {
						return [-1, 0];
					}
				} else if(x_or_y === 1) {
					if(enemy.y > player.y) {
						return [0, -1];
					} else if(enemy.y < player.y) {
						return [0, 1];
					}
				}
			} else if(enemy.y > player.y) {
				return [0, -1];
			} else if(enemy.y < player.y) {
				return [0, 1];
			}
		}
		return [0, 0];
	};
}
function button(x, y, width, height, text, click) {
	this.x = x;
	this.y = y;
	this.width  = width;
	this.height = height;
	this.text = text;
	this.click = click;
	this.color = "#00FF00";
	
	this.clicked = function(x, y) {
		if(this.x < x && this.y < y && this.x + this.width > x && this.y + this.height > y) {
			console.log(this.click);
			this.click();
			draw();
		}
	};
	
	this.draw = function() {
		context.fillStyle = this.color;
		context.rect(this.x, this.y, this.width, this.height);
		context.stroke();
		context.fillText(this.text, this.x + 2, this.y + this.height * .65);
	};
}
function enemy(x, y, room) {
	this.x = x;
	this.y = y;
	this.attack = 1;
	this.health = 10;
	this.skill = 9;
	this.xp_bounty = 18;
	this.room = room;
	var space_border = 2;

	this.recive_attack = function(damage, attacker) {
		hud.set_message("You dealt " + damage + " damage");
		this.take_damage(damage);
	};

	this.attack_enemy = function(target) {
		if(Math.random() <= this.skill / target.skill) {
			if(random_range(0, 100) <= this.skill - target.skill) {
				target.recive_attack(this.attack * this.attack);
				hud.set_message("You took critical damage");
			} else {
				target.recive_attack(this.attack);
			}
		} else {
			hud.set_message("Enemy missed");
		}
	};

	this.take_damage = function(damage) {
		this.health -= damage;
		if(this.health <= 0) {
			hud.set_message("Enemy killed");
		}
	};
	
	this.draw = function() {
		context.fillStyle = "#FF0000";
		context.fillRect(this.room.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.x) + space_border, this.room.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.y) + space_border, SPACE_SIZE - (space_border * 2), SPACE_SIZE - (space_border * 2));
	};
}

function hud(x, y, width, height) {
	
	this.next_level_button = function() {
		hud.buttons = [];
		new_level();
		transition_state("game");
	};
	
	this.increase_health_button = function() {
		player.level_skill("health");
	};
	
	this.increase_attack_button = function() {
		player.level_skill("attack");
	};
	
	this.increase_skill_button = function() {
		player.level_skill("skill");
	};
	
	this.x = x;
	this.y = y;
	this.font_size = 20;
	this.width = width;
	this.height = height;
	this.messages = [];
	this.buttons = [];
	
	var OSName="Unknown OS";
	if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
	if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
	if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
	if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";

	this.set_message = function(message) {
		this.messages.push(message);
		if(this.messages.length >= this.height / this.font_size / 2) {
			this.messages.shift();
		}
	};

	this.init_menu = function() {
		this.buttons.push(new button(40, 40, 122, 40, "Next Level", this.next_level_button));
		this.buttons.push(new button(40, 84, 122, 40, "+ Health", this.increase_health_button));
		this.buttons.push(new button(166, 84, 122, 40, "+ Attack", this.increase_attack_button));
		this.buttons.push(new button(292, 84, 122, 40, "+ Skill", this.increase_skill_button));
		this.messages = [];
	};

	this.draw = function() {
		if(state === "game") {
			this.draw_game();
		} else if(state === "menu") {
			this.draw_menu();
		}
		context.fillText("HEALTH: " + player.health + "/" + player.max_health, this.x + 20, this.y + 40);
		context.fillText("XP: " + player.xp + "/" + player.xpn, this.x + 200, this.y + 40);
		context.fillText("ATTACK: " + player.attack, this.x + 20, this.y + 80);
		context.fillText("SKILL: " + player.skill, this.x + 200, this.y + 80);
	};
	
	this.draw_game = function() {
		if(OSName === "MacOS") {
			context.font = this.font_size + "px Andale Mono";
		} else if(OSName === "Windows") {
			context.font = this.font_size + "px Lucida Console";
		}
		context.fillStyle = "#00FF00";
		context.strokeStyle = "#00FF00";
		context.lineWidth = "2";
		context.rect(this.x, this.y, this.width, this.height);
		context.stroke();
		for(var i = 0; i < this.messages.length; i++) {
			context.fillText(this.messages[i], this.x + 20, this.y + 120 + (20 * i));
		}
	};
	
	this.draw_menu = function() {
		if(OSName === "MacOS") {
			context.font = this.font_size + "px Andale Mono";
		} else if(OSName === "Windows") {
			context.font = this.font_size + "px Lucida Console";
		}
		context.fillStyle = "#00FF00";
		context.strokeStyle = "#00FF00";
		context.lineWidth = "2";
		context.rect(20, 20, canvas.width - 40, canvas.height - 40);
		context.stroke();
		context.fillText("Skill points: " + player.level_points, 40, 250);
		context.fillText("Controls:", 800, 450);
		context.fillText("W: Move up", 840, 470);
		context.fillText("A: Move left", 840, 490);
		context.fillText("S: Move down", 840, 510);
		context.fillText("D: Move right", 840, 530);
		context.fillText("Move into enemies to attack", 840, 550);
		for(var i = 0; i < this.buttons.length; i++) {
			this.buttons[i].draw();
		}
	};
}
canvas = document.getElementById('rogue');
context = canvas.getContext('2d');

//TODO: Use screen size to determine canvas size

var HUD_BUFFER = 10;
var HUD_WIDTH = canvas.width * .2;
var HUD_HEIGHT = canvas.height * .98;
var HUD_X = canvas.width - HUD_WIDTH - HUD_BUFFER;
var HUD_Y = canvas.height - HUD_HEIGHT - HUD_BUFFER;

var BLOCK_WIDTH = 10;
var BLOCK_HEIGHT = 15;
var BLOCK_DISTANCE = 10;
var SPACE_SIZE = 15;
var BLOCKS_WIDTH  =  Math.floor((canvas.width  - HUD_WIDTH  - HUD_BUFFER) / ((BLOCK_WIDTH  * SPACE_SIZE) + BLOCK_DISTANCE));
var BLOCKS_HEIGHT =  Math.floor((canvas.height)                           / ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE));

console.log(BLOCKS_WIDTH);
console.log(BLOCKS_HEIGHT);

var TICK_KEY_VALUES = [83, 68, 87, 65];

document.addEventListener("keydown", handle_keypress);
document.addEventListener("mouseup", handle_mouse_up);

var rooms = [];
var player = new player();
var state = "menu";
var hud = new hud(HUD_X, HUD_Y, HUD_WIDTH, HUD_HEIGHT);

new_level();
hud.init_menu();
draw();

function new_level() {
	rooms = [];
	for(var i = 0; i < BLOCKS_WIDTH; i++) {
	    rooms.push([]);
	}
	
	var r1 = new room(random_range(0, BLOCKS_WIDTH - 1), random_range(0, BLOCKS_HEIGHT - 1), 4, 4);
	var num_rooms = 1;
	var target_num_rooms = 250;
	
	r1.spawn_links(num_rooms, target_num_rooms);
	
	while(num_rooms < target_num_rooms){ 
	   spawn_rooms();
	   num_rooms += 1;
	}
	
	console.log(num_rooms);
	spawn_enemies(4);
	player.current_room = r1;
	player.x = 1;
	player.y = 1;
	r1.seen = true;
	r1.enemies = [];
	
	var exit_room = null;
	var exit_x;
	var exit_y;
	while(true) {
		exit_x = random_range(0, BLOCKS_WIDTH  - 1);
		exit_y = random_range(0, BLOCKS_HEIGHT - 1);
		if(typeof rooms[exit_x] !== "undefined" && typeof rooms[exit_x][exit_y] !== "undefined") {
			break;
		}
	}
	
	exit_room = rooms[exit_x][exit_y];
	exit_room.floor[random_range(1, exit_room.width - 2)][random_range(1, exit_room.height - 2)] = "x";

	player.health = player.max_health;
}

function spawn_rooms() {
    for(var i = BLOCKS_WIDTH - 1; i >= 0; i--){
        for(var j = BLOCKS_HEIGHT - 1; j >= 0; j--){
            if(typeof rooms[i][j] !== "undefined"){
                rooms[i][j].spawn_links();
                return;
            }
        }
    } 
}

function spawn_enemies(quantity) {
	for(var i = BLOCKS_WIDTH - 1; i >= 0; i--){
        for(var j = BLOCKS_HEIGHT - 1; j >= 0; j--){
            if(typeof rooms[i][j] !== 'undefined'){
                rooms[i][j].spawn_enemies(random_range(0, quantity));
            }
        }
    }
}

function draw() {
    canvas.width = canvas.width;
    context.fillStyle = "#000000";
    context.fillRect(0, 0, canvas.width, canvas.height);
    if(state === "game") {
	    for (var i = 0; i < rooms.length; i++) {
	        for (var j = 0; j < 10; j++) {
	            if(typeof rooms[i][j] !== 'undefined'){
	                rooms[i][j].draw();
	                //console.log(i + " " + j);
	                //console.log(rooms[i][j]);
	            }
	        }
	    }
	 	player.draw();
    }
    hud.draw();
}

function transition_state(new_state) {
	state = new_state;
	if(state === "menu") {
		hud.init_menu();
	}
	draw();
}

function handle_keypress(e) {
    var code = e.keyCode;
    var movement = [0, 0];
    if(code === 83) {
        movement = [0, 1];
    } else if(code === 68) {
        movement = [1, 0];
    } else if(code === 87) {
        movement = [0, -1];
    } else if(code === 65) {
        movement = [-1, 0];
    }
    if(TICK_KEY_VALUES.includes(code)) {
    	player.current_room.move_player(movement);
        player.current_room.move_enemies();
    	draw();
    }
}

function handle_mouse_up(e) {
	for(var i = 0; i < hud.buttons.length; i++) {
		hud.buttons[i].clicked(e.clientX, e.clientY);
	}
}

function player() {
	this.x;
	this.y;
	this.color = "#0000FF";
	this.attack = 4;
	this.max_health = 12;
	this.health = this.max_health;
	this.skill = 25;
	this.xp = 0;
	this.xpn = 100;
	this.level = 1;
	this.level_points = 1;
	this.current_room = null;
	var space_border = 1;
	
	this.attack_enemy = function(enemy) {
		if(Math.random() <= this.skill / enemy.skill) {
			if(random_range(0, 100) <= this.skill - enemy.skill) {
				enemy.recive_attack(this.attack * 2, this);
				hud.set_message("Critical hit");
			} else {
				enemy.recive_attack(this.attack, this);
			}
		} else {
			hud.set_message("You missed");
		}
	};

	this.recive_attack = function(damage) {
		this.take_damage(damage);
		hud.set_message("You were attacked, took " + damage + " damage");
	};

	this.take_damage = function(damage) {
		this.health -= damage;
		if(this.health <= 0) {
			this.color = "#FF00FF";
		}
	};

	this.gain_xp = function(amount) {
		this.xp += amount;
		if(this.xp >= this.xpn) {
			this.level_up();
		}
	};
	
	this.level_up = function() {
		this.level_points += 1;
		this.level += 1;
		this.xp -= this.xpn;
		hud.set_message("Level up");
	};
	
	this.level_skill = function(skill) {
		if(this.level_points > 0) {
			if(skill === "health") {
				this.max_health += 2;
				this.level_points -= 1;
			} else if (skill === "attack") {
				this.attack += 1;
				this.level_points -= 1;
			} else if (skill === "skill") {
				this.skill += 3;
				this.level_points -= 1;
			}
		}
	};

	this.draw = function() {
		context.fillStyle = this.color;
		context.fillRect(this.current_room.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.x) + space_border, this.current_room.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.y) + space_border, SPACE_SIZE - (space_border * 2), SPACE_SIZE - (space_border * 2));
	};
}
//-: open space, d: door
var OPEN_SPACES = ["-", "d", "x"];

function room(x, y, width, height) {
    this.north = null;
    this.south = null;
    this.east  = null;
    this.west  = null;

    this.north_door = null;
    this.south_door = null;
    this.east_door  = null;
    this.west_door  = null;

    this.x = x;
    this.y = y;
    this.width  = width;
    this.height = height;

	this.xcor = this.x * ((BLOCK_WIDTH  * SPACE_SIZE) + BLOCK_DISTANCE);
	this.ycor = this.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE);

    this.seen = false;

    this.floor = [];
    for(var i = 0; i < this.width; i++) {
        var row = [];
        for(var j = 0; j < this.height; j++) {
            row.push("-");
        }
        this.floor.push(row);
    }

    rooms[x][y] = this;
    
    this.enemies = [];
    this.enemy_x;
    this.enemy_y;

    this.ai = new ai();
    
    this.spawn_enemies = function(quantity) {
        for(var i = 0; i < quantity; i++) {
        	while(this.floor[this.enemy_x = random_range(1, this.width - 2)][this.enemy_y = random_range(1, this.height - 2)] !== "-");
        	this.enemy = new enemy(this.enemy_x, this.enemy_y, this);
            this.floor[this.enemy_x][this.enemy_y] = "e";
        	this.enemies.push(this.enemy);
        }
        for(var i = 0; i < this.floor.length; i++) {
            for(var j = 0; j < this.floor[i].length; j ++) {
                if(this.floor[i][j] === "e") {
                    this.floor[i][j] = "-";
                }
            }
        }
    };

    this.move_enemies = function() {
        for(var i = 0; i < this.enemies.length; i++) {
            var movement = this.ai.seek_and_attack_player(this.enemies[i]);
            if(this.validate_move(movement, this.enemies[i])) {
                this.enemies[i].x += movement[0];
                this.enemies[i].y += movement[1];
            }
        }
    };

    this.move_player = function(movement) {
        if(this.validate_move(movement, player)) {
            player.x += movement[0];
            player.y += movement[1];
            if(this.floor[player.x][player.y] === "d") {
                if(this.north_door !== null && this.north_door[0] === player.x && this.north_door[1] === player.y) {
                    player.current_room = this.north;
                    player.x = this.north.south_door[0];
                    player.y = this.north.south_door[1];
                } else if(this.south_door !== null && this.south_door[0] === player.x && this.south_door[1] === player.y) {
                    player.current_room = this.south;
                    player.x = this.south.north_door[0];
                    player.y = this.south.north_door[1];
                } else if(this.east_door !== null && this.east_door[0] === player.x && this.east_door[1] === player.y) {
                    player.current_room = this.east;
                    player.x = this.east.west_door[0];
                    player.y = this.east.west_door[1];
                } else if(this.west_door !== null && this.west_door[0] === player.x && this.west_door[1] === player.y) {
                    player.current_room = this.west;
                    player.x = this.west.east_door[0];
                    player.y = this.west.east_door[1];
                }
                player.current_room.seen = true;
            } else if(this.floor[player.x][player.y] === "x") {
            	transition_state("menu");
            }
        } else if(this.validate_attack(movement, player)) {
        	for(var i = 0; i < this.enemies.length; i++) {
            	if(this.enemies[i].x === player.x + movement[0] && this.enemies[i].y === player.y + movement[1]) {
            		player.attack_enemy(this.enemies[i]);
            		if(this.enemies[i].health <= 0) {
            			this.kill(this.enemies[i]);
            		}
                    return;
            	}
        	}
        }
    };
    
    this.kill = function(enemy) {
    	this.enemies.splice(this.enemies.indexOf(enemy), 1);
    	console.log(this.enemies);
        player.gain_xp(enemy.xp_bounty);
    };

    this.set_door = function(direction, room) {
        if(direction === "north" && this.north === null) {
            this.north = room;
            this.north_door = [random_range(1, this.width - 2), 0];
            this.floor[this.north_door[0]][this.north_door[1]] = 'd';
        } else if(direction === "south" && this.south === null) {
            this.south = room;
            this.south_door = [random_range(1, this.width - 2), this.height - 1];
            this.floor[this.south_door[0]][this.south_door[1]] = 'd';
        } else if(direction === "east" && this.east === null) {
            this.east = room;
            this.east_door = [this.width - 1, random_range(1, this.height - 2)];
            this.floor[this.east_door[0]][this.east_door[1]] = 'd';
        } else if(direction === "west" && this.west === null) {
            this.west = room;
            this.west_door = [0, random_range(1, this.height - 2)];
            this.floor[this.west_door[0]][this.west_door[1]] = 'd';
        }
    };

    this.validate_move = function(movement, unit) {
        if(typeof this.floor[unit.x + movement[0]] !== 'undefined' && typeof this.floor[unit.x + movement[0]][unit.y + movement[1]] !== 'undefined' && OPEN_SPACES.includes(this.floor[unit.x + movement[0]][unit.y + movement[1]])) {
            for(var i = 0; i < this.enemies.length; i++) {
            	if(unit.x + movement[0] === this.enemies[i].x && unit.y + movement[1] === this.enemies[i].y) {
            		return false;
            	}
            }
            return true;
        }
        return false;
    };

    this.validate_attack = function(movement, unit) {
        if(typeof this.floor[unit.x + movement[0]] !== 'undefined' && typeof this.floor[unit.x + movement[0]][unit.y + movement[1]] !== 'undefined') {
            return true;
        }
        return false;
    };

    this.draw = function() {
        context.fillStyle = "#00FF00";
        context.strokeStyle="#00FF00";
        context.lineWidth="2";
        var space_border = 2;
        if(this.seen) {
            if(player.current_room === this) {
                context.rect(this.xcor, this.ycor, this.width * SPACE_SIZE, this.height * SPACE_SIZE);
                context.stroke();
                for(var i = 0; i < this.floor.length; i++) {
                    for(var j = 0; j < this.floor[i].length; j ++) {
                        if(this.floor[i][j] === "-") {
                        	context.fillStyle = "#00FF00";
                        } else if(this.floor[i][j] === "x") {
                        	context.fillStyle = "#AAFF00";
                        } else {
                        	context.fillStyle = "#000000";
                        }
                        context.fillRect(this.xcor + (SPACE_SIZE * i) + space_border, this.ycor + (SPACE_SIZE * j) + space_border, SPACE_SIZE - (space_border * 2), SPACE_SIZE - (space_border * 2));
                    }
                }
                for(var i = 0; i < this.enemies.length; i++) {
                    this.enemies[i].draw();
                }
            } else {
                context.fillRect(this.xcor, this.ycor, this.width * SPACE_SIZE, this.height * SPACE_SIZE);
            }
            this.draw_doors();
        }
    };

    this.draw_doors = function() {
        if(this.north !== null) {
            context.beginPath();
            context.moveTo(this.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.north_door[0]) + SPACE_SIZE / 2, this.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.north_door[1]));
            context.lineTo(this.north.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.north.south_door[0]) + SPACE_SIZE / 2, this.north.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * (this.north.south_door[1] + 1)));
            context.stroke();
        }
        if(this.south !== null) {
            context.beginPath();
            context.moveTo(this.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.south_door[0]) + SPACE_SIZE / 2, this.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * (this.south_door[1] + 1)));
            context.lineTo(this.south.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.south.north_door[0]) + SPACE_SIZE / 2, this.south.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.south.north_door[1]));
            context.stroke();
        }
        if(this.east !== null) {
            context.beginPath();
            context.moveTo(this.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * (this.east_door[0] + 1)), this.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.east_door[1]) + SPACE_SIZE / 2);
            context.lineTo(this.east.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.east.west_door[0]), this.east.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * (this.east.west_door[1] + 1)) - SPACE_SIZE / 2);
            context.stroke();
        }
        if(this.west !== null) {
            context.beginPath();
            context.moveTo(this.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.west_door[0]), this.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * this.west_door[1]) + SPACE_SIZE / 2);
            context.lineTo(this.west.x * ((BLOCK_WIDTH * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * (this.west.east_door[0] + 1)), this.west.y * ((BLOCK_HEIGHT * SPACE_SIZE) + BLOCK_DISTANCE) + (SPACE_SIZE * (this.west.east_door[1] + 1)) - SPACE_SIZE / 2);
            context.stroke();
        }
    };

    this.spawn_links = function(num_rooms, target_num_rooms) {
        var spawn_weight = 70;
        var relink_weight = 50;
        var min_room_width = 4;
        var min_room_height = 4;
        var max_room_width = 7;
        var max_room_height = 7;
        if(num_rooms > target_num_rooms) {
            return;
        }
        if(random_range(0, 100) <= spawn_weight) {
            if(this.y > 0) {
                if(typeof rooms[x][y - 1] === 'undefined'){
                    this.set_door("north", new room(x, y - 1, random_range(min_room_width, max_room_width), random_range(min_room_height, max_room_height)));
                    this.north.set_door("south", this);
                    num_rooms += 1;
                    this.north.spawn_links(num_rooms, target_num_rooms);
                } else if(random_range(0, 100) <= relink_weight){
                    this.set_door("north", rooms[x][y - 1]);
                    this.north.set_door("south", this);
                }
            }
        }
        if(random_range(0, 100) <= spawn_weight) {
            if(this.y < BLOCKS_HEIGHT - 1) {
                if(typeof rooms[x][y + 1] === 'undefined'){
                    this.set_door("south", new room(x, y + 1, random_range(min_room_width, max_room_width), random_range(min_room_height, max_room_height)));
                    this.south.set_door("north", this);
                    num_rooms += 1;
                    this.south.spawn_links(num_rooms, target_num_rooms);
                } else if(random_range(0, 100) <= relink_weight){
                    this.set_door("south", rooms[x][y + 1]);
                    this.south.set_door("north", this);
                }
            }
        }
        if(random_range(0, 100) <= spawn_weight) {
            if(this.x < BLOCKS_WIDTH - 1) {
                if(typeof rooms[x + 1][y] === 'undefined'){
                    this.set_door("east", new room(x + 1, y, random_range(min_room_width, max_room_width), random_range(min_room_height, max_room_height)));
                    this.east.set_door("west", this);
                    num_rooms += 1;
                    this.east.spawn_links(num_rooms, target_num_rooms);
                } else if(random_range(0, 100) <= relink_weight){
                    this.set_door("east", rooms[x + 1][y]);
                    this.east.set_door("west", this);
                }
            }
        }
        if(random_range(0, 100) <= spawn_weight) {
            if(this.x > 0) {
                if(typeof rooms[x - 1][y] === 'undefined'){
                    this.set_door("west", new room(x - 1, y, random_range(min_room_width, max_room_width), random_range(min_room_height, max_room_height)));
                    this.west.set_door("east", this);
                    num_rooms += 1;
                    this.west.spawn_links(num_rooms, target_num_rooms);
                } else if(random_range(0, 100) <= relink_weight){
                    this.set_door("west", rooms[x - 1][y]);
                    this.west.set_door("east", this);
                }
            }
        }
    };

}
function random_range(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function are_adjacent(unit1, unit2) {
	if(unit1.x + 1 === unit2.x && unit1.y === unit2.y){
		return true;
	} else if(unit1.x - 1 === unit2.x && unit1.y === unit2.y){
		return true;
	} else if(unit1.x === unit2.x && unit1.y + 1 === unit2.y){
		return true;
	} else if(unit1.x === unit2.x && unit1.y - 1 === unit2.y){
		return true;
	}
	return false;
}